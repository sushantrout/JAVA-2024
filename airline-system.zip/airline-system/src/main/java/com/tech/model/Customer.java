package com.tech.model;

public class Customer extends Person {

}
