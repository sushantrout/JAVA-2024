package com.un;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
